#!/usr/bin/env python
# coding: utf-8

# In[1]:


import glob
import os
import datetime
from PyPDF2 import PdfFileWriter, PdfFileReader
import traceback


# In[2]:


def collage_pdf(file1,file2,out,path=None):
    
    pdf_writer = PdfFileWriter()
    read1 = PdfFileReader(file1)
    read2 = PdfFileReader(file2)
    for page in range(read1.getNumPages()):
        pdf_writer.addPage(read1.getPage(page))

    for page in range(read2.getNumPages()):
        pdf_writer.addPage(read2.getPage(page))

    with open(out, 'wb') as fh:
        pdf_writer.write(fh)
        
    return read2.getNumPages()


# In[3]:


# os.chdir('To_Merge')

time_str = str(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
out_file = 'merge'+ time_str +'.pdf'
log_file = 'merge_log'+time_str +'.txt'
Lfile = open(log_file,'w')

count = 0
page1 = 1
filelist = glob.glob("*.pdf")

intro_str = "Welcome to the Toolbox4Tiros!\n"+             "This tool helps merge all pdf files in the current directory lexicographically.\n\n"+            "Instructions:\n"+             "1. Since the tool merge in the lexicographical order, you may change the order by adding leading number (eg: 001, 035).\n"+             "2. The lexicographical order means the number order as [1, 10, 3, 5], so please add leading zeros as padding.\n"+             "3. Please remove the previous result before you do another try. \n\n" +             "The output file would be " + out_file

Lfile.writelines(intro_str)

Lfile.writelines("\n Include: \n")

try:
    for file in sorted(filelist, key=lambda s: s.lower()):
        count += 1
        Lfile.writelines(str(count)+': '+file+'\n')
        if count == 1:
            last_file = file
            read1 = PdfFileReader(last_file)
            page2 = read1.getNumPages()
            Lfile.writelines('\t page '+str(page1)+' - page '+str(page2)+'\n')
            continue
        elif count == 2:
            file2_page = collage_pdf(last_file,file,out_file,path=None)
        else:
#             print(count)
            file2_page = collage_pdf(out_file,file,out_file,path=None)
        page1 = page2 + 1
        page2 = page1 + file2_page - 1
        Lfile.writelines('\t page '+str(page1)+' - page '+str(page2)+'\n')
except Exception:
    traceback.print_exe(file=Lfile)
    
Lfile.close()
# os.chdir("..")

